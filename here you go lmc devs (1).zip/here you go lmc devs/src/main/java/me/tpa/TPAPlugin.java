package me.tpa;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.CommandExecutor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;

public class TPAPlugin extends JavaPlugin {
    private final Map<UUID, UUID> pendingRequests = new HashMap<>();
    private final Map<UUID, Long> requestTimestamps = new HashMap<>();

    @Override
    public void onEnable() {
        getCommand("tpa").setExecutor(new TPACommand());
        getCommand("tpaccept").setExecutor(new TPACommand());
        getCommand("tpdeny").setExecutor(new TPACommand());
    }

    public class TPACommand implements CommandExecutor {
        private final long REQUEST_TIMEOUT = 60 * 1000;

        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("Only players can use this command.");
                return true;
            }

            Player player = (Player) sender;
            switch (command.getName().toLowerCase()) {
                case "tpa":
                    if (args.length != 1) {
                        player.sendMessage("§cUsage: /tpa <player>");
                        return true;
                    }
                    Player target = Bukkit.getPlayerExact(args[0]);
                    if (target == null || !target.isOnline()) {
                        player.sendMessage("§cPlayer not found.");
                        return true;
                    }
                    if (target == player) {
                        player.sendMessage("§cYou cannot send a request to yourself.");
                        return true;
                    }

                    pendingRequests.put(target.getUniqueId(), player.getUniqueId());
                    requestTimestamps.put(target.getUniqueId(), System.currentTimeMillis());
                    player.sendMessage("§aTPA request sent to §e" + target.getName());
                    target.sendMessage("§e" + player.getName() + " §awants to teleport to you. Type §6/tpaccept §aor §c/tpdeny§a.");
                    return true;

                case "tpaccept":
                    if (!pendingRequests.containsKey(player.getUniqueId())) {
                        player.sendMessage("§cYou have no pending teleport requests.");
                        return true;
                    }

                    long sentTime = requestTimestamps.getOrDefault(player.getUniqueId(), 0L);
                    if (System.currentTimeMillis() - sentTime > REQUEST_TIMEOUT) {
                        player.sendMessage("§cThis request has expired.");
                        pendingRequests.remove(player.getUniqueId());
                        return true;
                    }

                    Player requester = Bukkit.getPlayer(pendingRequests.get(player.getUniqueId()));
                    if (requester != null && requester.isOnline()) {
                        requester.teleport(player);
                        requester.sendMessage("§aYour teleport request to §e" + player.getName() + " §awas accepted.");
                        player.sendMessage("§aYou accepted the teleport request.");
                    } else {
                        player.sendMessage("§cThe player is no longer online.");
                    }

                    pendingRequests.remove(player.getUniqueId());
                    return true;

                case "tpdeny":
                    if (!pendingRequests.containsKey(player.getUniqueId())) {
                        player.sendMessage("§cYou have no pending teleport requests.");
                        return true;
                    }
                    Player denyRequester = Bukkit.getPlayer(pendingRequests.get(player.getUniqueId()));
                    if (denyRequester != null && denyRequester.isOnline()) {
                        denyRequester.sendMessage("§cYour teleport request to §e" + player.getName() + " §cwas denied.");
                    }
                    player.sendMessage("§cYou denied the teleport request.");
                    pendingRequests.remove(player.getUniqueId());
                    return true;
            }
            return false;
        }
    }
}
