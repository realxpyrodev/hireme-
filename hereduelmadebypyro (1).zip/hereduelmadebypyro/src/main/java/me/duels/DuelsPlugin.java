package me.duels;

import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;

public class DuelsPlugin extends JavaPlugin implements Listener {
    private final Map<UUID, UUID> duelRequests = new HashMap<>();
    private final Set<UUID> inDuel = new HashSet<>();
    private Location arenaLocation;
    private Location spawnLocation;

    @Override
    public void onEnable() {
        getCommand("duel").setExecutor(this::duelCommand);
        getCommand("duelaccept").setExecutor(this::acceptCommand);
        getCommand("setarena").setExecutor(this::setArenaCommand);
        getCommand("setspawn").setExecutor(this::setSpawnCommand);
        getServer().getPluginManager().registerEvents(this, this);
    }

    private boolean duelCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player) || args.length != 1) return false;
        Player challenger = (Player) sender;
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null || target == challenger) {
            challenger.sendMessage("§cInvalid player.");
            return true;
        }
        duelRequests.put(target.getUniqueId(), challenger.getUniqueId());
        challenger.sendMessage("§aDuel request sent to §e" + target.getName());
        target.sendMessage("§e" + challenger.getName() + " §awants to duel. Type §6/duelaccept §ato fight.");
        return true;
    }

    private boolean acceptCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) return false;
        Player target = (Player) sender;
        UUID challengerId = duelRequests.remove(target.getUniqueId());
        if (challengerId == null) {
            target.sendMessage("§cNo duel request found.");
            return true;
        }
        Player challenger = Bukkit.getPlayer(challengerId);
        if (challenger == null) {
            target.sendMessage("§cChallenger is offline.");
            return true;
        }
        if (arenaLocation == null || spawnLocation == null) {
            target.sendMessage("§cArena or spawn not set.");
            return true;
        }

        inDuel.add(challenger.getUniqueId());
        inDuel.add(target.getUniqueId());

        challenger.teleport(arenaLocation.clone().add(2, 0, 0));
        target.teleport(arenaLocation.clone().add(-2, 0, 0));
        Bukkit.broadcastMessage("§e" + challenger.getName() + " §7vs §e" + target.getName() + " §f– Duel started!");

        return true;
    }

    private boolean setArenaCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("duels.admin")) {
            sender.sendMessage("§cYou do not have permission to use this command.");
            return true;
        if (!(sender instanceof Player)) return false;
        arenaLocation = ((Player) sender).getLocation();
        sender.sendMessage("§aArena location set.");
        return true;
    }

    private boolean setSpawnCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) return false;
        spawnLocation = ((Player) sender).getLocation();
        sender.sendMessage("§aSpawn location set.");
        return true;
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent e) {
        Player dead = e.getEntity();
        if (!inDuel.contains(dead.getUniqueId())) return;
        Player killer = dead.getKiller();

        inDuel.remove(dead.getUniqueId());
        if (killer != null) {
            inDuel.remove(killer.getUniqueId());
            Bukkit.broadcastMessage("§c" + dead.getName() + " was defeated by " + killer.getName() + "!");
            Bukkit.getScheduler().runTaskLater(this, () -> {
                killer.teleport(spawnLocation);
            }, 60L);
        }

        Bukkit.getScheduler().runTaskLater(this, () -> {
            dead.spigot().respawn();
            dead.teleport(spawnLocation);
        }, 60L);
    }
}
